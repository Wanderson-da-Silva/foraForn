package com.br.foraforn2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.br.foraforn2.databinding.ActivityMainCadUsuarioBinding
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

private lateinit var bindingUU : ActivityMainCadUsuarioBinding

private val retrofit = Retrofit.Builder().addConverterFactory(GsonConverterFactory.create())
    .baseUrl("http://10.0.2.2/users/").build().create(Main_CadUsuario.alter::class.java)

class Main_CadUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        bindingUU=ActivityMainCadUsuarioBinding.inflate(layoutInflater)
        setContentView(bindingUU.root)

        var intentL = intent

        val matricula = bindingUU.editCadMatriculaUsuario
        val nome = bindingUU.editCadLoginUsuario
        val senha = bindingUU.editCadSenhaUsuario
        val tipo = bindingUU.editCadTipoUsuario

//        matricula.text = intentL.getStringExtra("matricula")
//        nome.text = intentL.getStringExtra("nome")
//        senha.text = intentL.getStringExtra("senha")
//        tipo.text = intentL.getStringExtra("tipo")
        val matriculaD = intentL.getStringExtra("matricula")
        matricula.setText(matriculaD)
        val nomeD = intentL.getStringExtra("nome")
        nome.setText(nomeD)
        val senhaD = intentL.getStringExtra("senha")
        senha.setText(senhaD)
        val tipoD = intentL.getStringExtra("tipo")
        tipo.setText(tipoD)

        bindingUU.btnCancelCadUser.setOnClickListener{
            irCruzamento()
        }
        bindingUU.btnSaveCadUser.setOnClickListener{
            val user = UsuarioModel(
                bindingUU.editCadMatriculaUsuario.text.toString(),bindingUU.editCadLoginUsuario.text.toString(),bindingUU.editCadSenhaUsuario.text.toString(),bindingUU.editCadTipoUsuario.text.toString()
            )

            chamarAPI(user)
        }
    }


    private fun irCruzamento(){
        Toast.makeText(this,"Edição cancelada!!!", Toast.LENGTH_SHORT).show()
        val enviar = Intent(this, Main_Cruzamento::class.java)
        startActivity(enviar)
    }
    private fun chamarAPI(userr :UsuarioModel){
//    Toast.makeText(this,"User: "+ user.nome +" senha : "+user.senha+"!!!",Toast.LENGTH_SHORT).show()

//        Toast.makeText(this,"A matricula  "+ userr.matriculaUsuario +" !!!", Toast.LENGTH_SHORT).show()
        retrofit.envUser(
            userr.nomeUsuario,
            userr.senhaUsuario,
            userr.matriculaUsuario,
            userr.tipoUsuario
        ).enqueue(object : Callback<UsuarioModel> {
            override fun onResponse(call: Call<UsuarioModel>, response: Response<UsuarioModel>) {
                if(response.isSuccessful){

                    response.body()?.let {
                        val responseJson = response.body().toString()
                        Log.d("Response JSON:", responseJson)
                        if(response.body()!!.matriculaUsuario.equals("vazio")){

                            resultMsg(false)
                        }else{
                            resultMsg(true)
                        }
                    }
                }
            }

            override fun onFailure(call: Call<UsuarioModel>, t: Throwable) {


                Log.d("user: ",userr.senhaUsuario)
                Log.d("nome:",userr.nomeUsuario)
                Log.d("tipo:",userr.tipoUsuario)
                Log.d("matricula:",userr.matriculaUsuario)
                Log.d("Erro cad user:",t.toString())
                t.printStackTrace()

            }




        })
//    Toast.makeText(this,"Usuario Autenticado fim!!!",Toast.LENGTH_SHORT).show()

    }
    private fun resultMsg(resp: Boolean){
        if(resp){
            Toast.makeText(this,"Usuario Cadastrado!!!",Toast.LENGTH_SHORT).show()
            val enviar = Intent(this, Main_Cruzamento::class.java)
            startActivity(enviar)
        }else{
            Toast.makeText(this,"Erro no cadastro!!",Toast.LENGTH_SHORT).show()
        }

    }

    interface alter{

        @FormUrlEncoded
        @POST("usuarioEd.php")
        fun envUser(
            @Field("nomeUsuario") nomeUsuario: String,
            @Field("senhaUsuario") senhaUsuario: String,
            @Field("matriculaUsuario") matriculaUsuario: String,
            @Field("tipoUsuario") tipoUsuario: String
        ) :Call<UsuarioModel>



    }
}




