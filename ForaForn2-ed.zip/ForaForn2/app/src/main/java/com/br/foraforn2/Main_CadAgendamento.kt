package com.br.foraforn2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Main_CadAgendamento : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_cad_agendamento)
    }
}