package com.br.foraforn2

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import okhttp3.ResponseBody
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

private val retrofit = Retrofit.Builder().addConverterFactory(GsonConverterFactory.create())
    .baseUrl("http://10.0.2.2/").build().create(UsuarioAdapter.buscarUser::class.java)
private val retrofit2 = Retrofit.Builder().addConverterFactory(GsonConverterFactory.create())
    .baseUrl("http://10.0.2.2/").build().create(UsuarioAdapter.deletuser::class.java)

class UsuarioAdapter(private val usuarios: List<UsuarioModel>, private val contexto: Context): RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder>() {


    inner class UsuarioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val deletButton = itemView.findViewById<Button>(R.id.btn_deletar)
        val editButton = itemView.findViewById<Button>(R.id.btn_editar)
        val matricula = itemView.findViewById<TextView>(R.id.text_idUser)
        val nome = itemView.findViewById<TextView>(R.id.text_nomeUser)
        val senha = itemView.findViewById<TextView>(R.id.text_senhaUser)
        val tipo = itemView.findViewById<TextView>(R.id.text_tipoUser)

        init {
            editButton.setOnClickListener {
                val user = usuarios[getAbsoluteAdapterPosition()]

                val userId = user.matriculaUsuario?.let { it1 -> UsuarioModelMt(it1) }

                    user.matriculaUsuario
                // Faça algo com o ID do item, como iniciar uma atividade de edição
                userId?.let { it1 -> bucarInf(it1,contexto) }
            }
            deletButton.setOnClickListener {
                val user = usuarios[getAbsoluteAdapterPosition()]



//                val userId = user.matriculaUsuario?.let { it1 -> UsuarioModelMt(it1) }


                // Faça algo com o ID do item, como iniciar uma atividade de edição
                deletInf(user = user.matriculaUsuario.toString(), cont = contexto)
            }

        }
    }
    private fun bucarInf(user :UsuarioModelMt, cont: Context){
//    Toast.makeText(this,"User: "+ user.nome +" senha : "+user.senha+"!!!",Toast.LENGTH_SHORT).show()

        retrofit.carrUser(
            user.matriculaUsuario
        ).enqueue(object : Callback<UsuarioModel> {
            override fun onResponse(call: Call<UsuarioModel>, response: Response<UsuarioModel>) {
                if(response.isSuccessful){

                    resultPesq(response,cont)
                }
            }

            override fun onFailure(call: Call<UsuarioModel>, t: Throwable) {

                Log.d("Erroes :",t.toString())

            }


        })
//    Toast.makeText(this,"Usuario Autenticado fim!!!",Toast.LENGTH_SHORT).show()

    }

    private fun deletInf(user: String, cont: Context){
        retrofit2.deletaUser(user).enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {

                    if(response.equals(false)){
                        Log.d("Delet Sem Sucesso:", response.toString())
                        val cargList = Intent(cont, Main_ListaUsuarios::class.java)
                        cont.startActivity(cargList)
                    }else{
                        Log.d("Delet Sucesso:", response.toString())
                        val cargList = Intent(cont, Main_ListaUsuarios::class.java)
                        cont.startActivity(cargList)
                    }

                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Log.d("Erro delete:", t.toString())
            }
        })
//    Toast.makeText(this,"Usuario Autenticado fim!!!",Toast.LENGTH_SHORT).show()

    }
    private fun resultPesq(user: Response<UsuarioModel>, contt: Context){
        val usuario = user.body() // Obtém o objeto UsuarioModel do Response

        val enviar = Intent(contt, Main_CadUsuario::class.java)

        enviar.putExtra("matricula", usuario?.matriculaUsuario)
        enviar.putExtra("nome", usuario?.nomeUsuario)
        enviar.putExtra("senha", usuario?.senhaUsuario)
        enviar.putExtra("tipo", usuario?.tipoUsuario)
        enviar.putExtra("EXTRA_ALLOW",false)
        contt.startActivity(enviar)

    }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {

            //criar visualizacoes
            val campoUser = LayoutInflater.from(parent.context)
                .inflate(R.layout.container_usuarios, parent, false)
            val holde = UsuarioViewHolder(campoUser)
            return holde
        }

        override fun onBindViewHolder(holde: UsuarioViewHolder, position: Int) {
            //exibir visualizações
            val user = usuarios[position]
//            holde.matricula.setImageResource(usuarios[position].matriculaUsuario)
            holde.matricula.text= usuarios[position].matriculaUsuario
            holde.nome.text = usuarios[position].nomeUsuario
            holde.senha.text = usuarios[position].senhaUsuario
            holde.tipo.text = usuarios[position].tipoUsuario

            holde.editButton.tag = user.matriculaUsuario
        }

        //total da lista
        override fun getItemCount(): Int = usuarios.size

    interface buscarUser{


        @GET("users/usuario.php")
        fun carrUser( @Query("matriculaUsuarioEd") matriculaUsuarioEd : String) : Call<UsuarioModel>



    }
    interface deletuser{
        @FormUrlEncoded
        @POST("users/usuarioEd.php")
        fun deletaUser(

            @Field("matriculaUsuarioEx") matriculaUsuarioEx: String?
        ): Call<ResponseBody>

    }

    }








