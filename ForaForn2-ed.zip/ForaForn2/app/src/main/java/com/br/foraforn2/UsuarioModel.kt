package com.br.foraforn2

data class UsuarioModel(


 val nomeUsuario: String,
 val senhaUsuario: String,
 val tipoUsuario: String,
 val matriculaUsuario: String
)
