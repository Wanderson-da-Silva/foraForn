package com.br.foraforn2

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.br.foraforn2.databinding.ActivityMainListaUsuariosBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST


private lateinit var bindingU : ActivityMainListaUsuariosBinding
private val retrofit = Retrofit.Builder().addConverterFactory(GsonConverterFactory.create())
    .baseUrl("http://10.0.2.2/users/").build().create(Main_ListaUsuarios.buscarUsers::class.java)


class Main_ListaUsuarios : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_lista_usuarios)
        bindingU = ActivityMainListaUsuariosBinding.inflate(layoutInflater)

        val view = bindingU.root

        setContentView(view)


        val car ="trevo"


        buscarUsuarios(car)



    }

    private fun buscarUsuarios(car: String) {
        retrofit.carrUser(car).enqueue(object : Callback<List<UsuarioModel>> {
            override fun onResponse(call: Call<List<UsuarioModel>>, response: Response<List<UsuarioModel>>) {
                if(response.isSuccessful){
                    val usuar = response.body()
//                    val jsonArray = JSONArray(usuar)
//                    val jsonObject: JSONObject = jsonArray.getJSONObject(0)
//                        if(jsonObject.getString("nomeUsuario").equals("vazio")){
//                            resultMsg()
//                        }else{

                            Listar(usuar)
//                        }

                }
            }

            override fun onFailure(call: Call<List<UsuarioModel>>, t: Throwable) {
                Log.d("Erro :",t.toString())
            }
        } )


    }

    private fun resultMsg(){

        Toast.makeText(this,"Usuários carregados sem sucesso!!!", Toast.LENGTH_SHORT).show()


    }

    private fun Listar(response: List<UsuarioModel>?) {
//        response
        //conectando recicleview na variavel
        val recicleView_usuarios = bindingU.listUsuarios
        //definindo organizacao da lista - lista na vertical u em baixo do outro
        recicleView_usuarios.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        //lista de usuarios

        recicleView_usuarios.adapter = response?.let { UsuarioAdapter(it, this) }

    }

    interface buscarUsers{

        @FormUrlEncoded
        @POST("usuario.php")
        fun carrUser( @Field("carr") nome : String) : Call<List<UsuarioModel>>
    }
}