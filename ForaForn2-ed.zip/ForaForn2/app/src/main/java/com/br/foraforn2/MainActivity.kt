package com.br.foraforn2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.br.foraforn2.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.Retrofit.Builder
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

private lateinit var bindingP : ActivityMainBinding

private val retrofit = Builder().addConverterFactory(GsonConverterFactory.create())
    .baseUrl("http://10.0.2.2/").build().create(MainActivity.loginn::class.java)



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindingP = ActivityMainBinding.inflate(layoutInflater)

        val view = bindingP.root

        setContentView(view)

        bindingP.btnLoginEntrar.setOnClickListener{

//            Toast.makeText(this,"Usuario Autenticado!!!",Toast.LENGTH_SHORT).show()
            val user = Usuario()
            user.nome = bindingP.editLoginUser.text.toString()
            user.senha = bindingP.editLoginPass.text.toString()

            if(TextUtils.isEmpty(bindingP.editLoginUser.text.toString())){
                Toast.makeText(this,"Campo Usuário em brnaco!",Toast.LENGTH_LONG).show()

                bindingP.editLoginUser.requestFocus()
            }
            else if(TextUtils.isEmpty(bindingP.editLoginPass.text.toString())){
            Toast.makeText(this,"Campo Senha em brnaco!",Toast.LENGTH_LONG).show()

            bindingP.editLoginPass.requestFocus()
        }else{
//                chama a API
                autentic(user)
        }





        }

    }
private fun autentic(user :Usuario){
//    Toast.makeText(this,"User: "+ user.nome +" senha : "+user.senha+"!!!",Toast.LENGTH_SHORT).show()

    retrofit.envUser(
        user.nome,
        user.senha
    ).enqueue(object : Callback<Usuario>{
        override fun onResponse(call: Call<Usuario>, response: Response<Usuario>) {
            if(response.isSuccessful){

                response.body()?.let {
                    if(response.body()!!.nome.equals("vazio")){

                        resultMsg(false)
                    }else{
                        resultMsg(true)
                    }
                }
            }
        }

        override fun onFailure(call: Call<Usuario>, t: Throwable) {

            Log.d("Erro :",t.toString())

        }


    })
//    Toast.makeText(this,"Usuario Autenticado fim!!!",Toast.LENGTH_SHORT).show()

}

    private fun resultMsg(resp: Boolean){
        if(resp){
            Toast.makeText(this,"Usuario Autenticado!!!",Toast.LENGTH_SHORT).show()
            val enviar = Intent(this, Main_Cruzamento::class.java)
            startActivity(enviar)
        }else{
            Toast.makeText(this,"Senha ou usuario errados!!",Toast.LENGTH_SHORT).show()
        }

    }

    interface loginn{

        @FormUrlEncoded
        @POST("autent.php")
        fun envUser(
            @Field("nome") nome : String,
            @Field("senha") senha : String
        ) :Call<Usuario>
    }
}