package com.br.foraforn2

class Usuario {
    lateinit var nome : String
    lateinit var senha : String




}
