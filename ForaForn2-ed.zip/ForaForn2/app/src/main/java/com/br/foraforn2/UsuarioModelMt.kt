package com.br.foraforn2

data class UsuarioModelMt(

    val matriculaUsuario: String


)