package com.br.foraforn2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.br.foraforn2.databinding.ActivityMainCadUsuarioBinding

private lateinit var bindingUU : ActivityMainCadUsuarioBinding

class Main_CadUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_cad_usuario)

        bindingUU=ActivityMainCadUsuarioBinding.inflate(layoutInflater)

        val view = bindingUU.root

        setContentView(view)


    }
}