package com.br.foraforn2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import com.br.foraforn2.databinding.ActivityMainCruzamentoBinding




private lateinit var binding : ActivityMainCruzamentoBinding

class Main_Cruzamento : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_cruzamento)

        binding =  ActivityMainCruzamentoBinding.inflate(layoutInflater)

        val view = binding.root

        setContentView(view)

        binding.btnAcesUser.setOnClickListener{
            val enviar = Intent(this, Main_CadUsuario::class.java)
            startActivity(enviar)
        }
        binding.btnAcesUserList.setOnClickListener{
            val enviar = Intent(this, Main_ListaUsuarios::class.java)
            startActivity(enviar)
        }
        binding.btnAcesRelatRio.setOnClickListener{
            val enviar = Intent(this, Main_Relatorio::class.java)
            startActivity(enviar)
        }
        binding.btnAcesPainel.setOnClickListener{
            val enviar = Intent(this, Main_Painel::class.java)
            startActivity(enviar)
        }
        binding.btnAcesMerc.setOnClickListener{
            val enviar = Intent(this, Main_CadMercadoria::class.java)
            startActivity(enviar)
        }
        binding.btnAcesItemM.setOnClickListener{
            val enviar = Intent(this, Main_CadItemMerc::class.java)
            startActivity(enviar)
        }
        binding.btnAcesItem.setOnClickListener{
            val enviar = Intent(this, Main_CadItem::class.java)
            startActivity(enviar)
        }
        binding.btnAcesForn.setOnClickListener{
            val enviar = Intent(this, Main_CadFornecedor::class.java)
            startActivity(enviar)
        }
        binding.btnAcesAgend.setOnClickListener{
            val enviar = Intent(this, Main_CadAgendamento::class.java)
            startActivity(enviar)
        }

    }
}