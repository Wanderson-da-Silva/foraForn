package com.br.foraforn2

data class UsuarioModel(

 val matriculaUsuario: String,
 val nomeUsuario: String,
 val senhaUsuario: String,
 val tipoUsuario: String

)
data class UsuarioModelMt(

 val matriculaUsuario: String,


)